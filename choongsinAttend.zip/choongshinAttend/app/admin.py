from django.contrib import admin
from .models import Child, Attend

# Register your models here.
admin.site.register(Child)
admin.site.register(Attend)
